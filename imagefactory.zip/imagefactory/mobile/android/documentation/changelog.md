# Change Log
<pre>
v2.2.1	[MOD-940] Building with 2.1.3.GA and open sourcing
	
v2.2	[MOD-447] Introduced "format" property. Default format is now JPEG, allowing for compression. Check out documentation to learn more.

v2.1	[MOD-309] Resolved memory allocation issue when using Android BitmapFactory API. All current module APIs impacted.

v2.0	Upgraded to module api version 2 for 1.8.0.1

v1.1	[MOD-309] Added "compressToFile"

v1.0	Initial Release
